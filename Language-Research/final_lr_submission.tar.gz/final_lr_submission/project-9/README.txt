Contents of project-9
======================

* english-bhojpuri_aligned.txt
Contains English sentence (E), Bhojpuri translation transliterated in English (T) , Bhojpuri translation in Native
script (B) and the alignment (A) in the form ( eng_word_pos - bhojpuri_word_pos )

Details of the informants
1. Aryaa Gautam - 1st year CIS Masters student at Upenn (aryaa.gautam@facebook.com)
2. Pranav Sahay - 2nd year CIS Masters student at Upenn (pranav.sahay@facebook.com)
3. Sanket Shukla - Postdoctoral Researcher at Upenn School of Medicine (sanket.shukla.716@facebook.com)
